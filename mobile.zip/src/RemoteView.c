#include "mobile.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#define ID_BACK                     101
#define ID_CLEAR                    102
#define ID_DOT                      103
#define ID_EQUAL                    104
#define ID_PLUS                     111
#define ID_MINUS                    112
#define ID_MULTIPLY                113
#define ID_DIVIDE                   114
#define ID_X2                       121
#define ID_X3                       122
#define ID_SQRT                     123
#define ID_RECIPE                   124


extern int * sock;


typedef struct item_data
{
   int index;
   Elm_Object_Item *item;
}item_data_s;
Evas_Object *img;
Evas_Object *entry;
char* value;
int calc_mode;
char* text = NULL;

static void set_entry_value(char* value)
{
   char buf[100];
   sprintf(buf, "%s", value);
   elm_object_text_set(entry, buf);
}
static char* get_entry_value2()
{
   char* text = elm_object_text_get(entry);
   return text;
}

static void
my_table_pack(Evas_Object *table, Evas_Object *child, int x, int y, int w, int h)
{
   evas_object_size_hint_align_set(child, EVAS_HINT_FILL, EVAS_HINT_FILL);
   evas_object_size_hint_weight_set(child, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
   elm_table_pack(table, child, x, y, w,h);
   evas_object_show(child);
}

void
btn_back_cb(void *data, Evas_Object *obj, void *event_info)
{
   Evas_Object *nf = data;
   elm_naviframe_item_pop(nf);
}

void
btn_turn_on(void * data, Evas_Object *obj, void *event_info)
{
   //printf("Test");

   SendMessage2("PowerOn",*sock);
}

void
btn_turn_off(void * data, Evas_Object *obj, void *event_info)
{
   //printf("Test");

   SendMessage2("PowerOff",*sock);
}

void
btn_volume_up(void * data, Evas_Object *obj, void *event_info)
{
   //printf("Test");

   SendMessage2("VolumeUp",*sock);
}

void
btn_volume_down(void * data, Evas_Object *obj, void *event_info)
{
   //printf("Test");
   SendMessage2("VolumeDown",*sock);

}

static char*
gl_text_get_cb(void *data, Evas_Object *obj, const char *part)
{
   const char *items[] = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
   item_data_s *id = data;
   if (!strcmp(part, "elm.text"))
   {
      return strdup(items[id->index]);
   }

   return NULL;
}

static void
gl_del_cb(void *data, Evas_Object *obj)
{
   item_data_s *id = data;
   free(id);
}
static float get_entry_value()
{
   char* text = elm_object_text_get(entry);
   float value = atof(text);
   return value;
}

static void
append_number_label(char str_new)
{
   char buf[100];


    char* text = elm_object_text_get(entry);
    float value = get_entry_value();
    if( value == 0.f )
        sprintf(buf, "%c", str_new);
    else
       sprintf(buf, "%s%c", text, str_new);

    elm_object_text_set(entry, buf);
}

static void
btn_clicked_cb(void *data, Evas_Object *obj, void *event_info)
{
    text = NULL;
    int length = 0;
    float value = 0.f;
    int id = (int)data;

    if( id >= 0 && id <= 9 )
    {
       append_number_label('0' + id);
       return;
    }
    switch( id )
    {
     case ID_CLEAR :
        elm_object_text_set(entry, "0");
        break;
     case ID_BACK :
        text = elm_object_text_get(entry);
        length = strlen(text);
        if( length > 0 )
           text = eina_stringshare_add_length(text, length - 1);
        if( strlen(text) < 1 )
           text = "0";
        elm_object_text_set(entry, text);
        break;

     case ID_EQUAL :
        get_entry_value2();
        break;
    }
}

static void
create_button(Evas_Object *parent, const char* text, int x, int y, int w, int h, void *data)
{
   Evas_Object *btn = elm_button_add(parent);
   elm_object_text_set(btn, text);

   evas_object_size_hint_weight_set(btn, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
   evas_object_size_hint_align_set(btn, EVAS_HINT_FILL, EVAS_HINT_FILL);
   my_table_pack(parent, btn, x, y, w, h);
   evas_object_smart_callback_add(btn, "clicked", btn_clicked_cb, data);
   evas_object_show(btn);
/*
   img = elm_image_add(btn);
   elm_image_file_set(img, ICON_DIR"/11.png", NULL);
   elm_image_resizable_set(img, EINA_TRUE, EINA_TRUE);
   elm_object_part_content_set(btn, "icon",img);
      //evas_object_size_hint_min_set(btn, ELM_SCALE_SIZE(64), ELM_SCALE_SIZE(64));
*/
}

static Evas_Object*
create_button_view2(Evas_Object *parent, Evas_Object *nf)
{
   Evas_Object *btn, *img, *box, *grid;
   grid = elm_grid_add(parent);
   elm_grid_size_set(grid, 720, 1280);
   evas_object_size_hint_weight_set(grid, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
   evas_object_size_hint_align_set(grid, EVAS_HINT_FILL, EVAS_HINT_FILL);
   //elm_bg_color_set(grid, 255, 255, 255);
   evas_object_show(grid);
   //Evas_Object *bg = elm_bg_add(grid);
   //elm_grid_pack(grid, bg, 0, 0, 720, 1280);
   //elm_bg_color_set(bg, 255, 255, 255);
   //evas_object_show(bg);

   /* icon_reorder style */
   btn = elm_button_add(grid);
   elm_object_style_set(btn, "icon_reorder");
   evas_object_smart_callback_add(btn, "clicked", btn_back_cb, nf);
   elm_grid_pack(grid,btn,320,30,70,70);
   evas_object_show(btn);

   btn = elm_button_add(grid);
   elm_object_text_set(btn,"<b>turn on</b>");
   evas_object_smart_callback_add(btn,"clicked",btn_turn_on,nf);
   elm_grid_pack(grid,btn,65,120,600,100);
   evas_object_show(btn);


   btn = elm_button_add(grid);
   elm_object_text_set(btn,"<b>turn off</b>");
   evas_object_smart_callback_add(btn,"clicked",btn_turn_off,nf);
   elm_grid_pack(grid,btn,65,240,600,100);
   evas_object_show(btn);


   btn = elm_button_add(grid);
   elm_object_text_set(btn,"<b>volume up</b>");
   evas_object_show(btn);
   evas_object_smart_callback_add(btn,"clicked",btn_volume_up,nf);
   elm_grid_pack(grid,btn,65,360,600,100);

   btn = elm_button_add(grid);
   elm_object_text_set(btn,"<b>volume down</b>");
   evas_object_show(btn);
   evas_object_smart_callback_add(btn,"clicked",btn_volume_down,nf);
   elm_grid_pack(grid,btn,65,480,600,100);

   /* Table */
   Evas_Object *table = elm_table_add(grid);
   /* Make table homogenous - every cell will be the same size */
   elm_table_homogeneous_set(table, EINA_TRUE);
   /* Set padding of 10 pixels multiplied by scale factor of UI */
   elm_table_padding_set(table, 10 * elm_config_scale_get(), 10 * elm_config_scale_get());
   /* Let the table child allocation area expand within in the box */
   evas_object_size_hint_weight_set(table, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
   /* Set table to fill width but align to bottom of box */
   evas_object_size_hint_align_set(table, EVAS_HINT_FILL, 1.0);
   elm_object_content_set(parent, table);
   evas_object_show(table);
   //my_box_pack(box, table, 1.0, 1.0, -1.0, 1.0);
   elm_grid_pack(grid,table,10,650,700,600);

   entry = elm_entry_add(parent);
   elm_object_text_set(entry, "0");
   evas_object_size_hint_weight_set(entry, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
   evas_object_size_hint_align_set(entry, EVAS_HINT_FILL, EVAS_HINT_FILL);
   my_table_pack(table, entry, 0, 0, 3, 1);
   //evas_object_show(entry);


   create_button(table, "<font_size=60><b>7</b></font_size>", 0, 1, 1, 1, 7);
   create_button(table, "<font_size=60><b>8</b></font_size>", 1, 1, 1, 1, 8);
   create_button(table, "<font_size=60><b>9</b></font_size>", 2, 1, 1, 1, 9);
   //create_button(table, "/", 3, 2, 1, 1, ID_DIVIDE);

   create_button(table, "<font_size=60><b>4</b></font_size>", 0, 2, 1, 1, 4);
   create_button(table, "<font_size=60><b>5</b></font_size>", 1, 2, 1, 1, 5);
   create_button(table, "<font_size=60><b>6</b></font_size>", 2, 2, 1, 1, 6);
   //create_button(table, "*", 3, 3, 1, 1, ID_MULTIPLY);


   create_button(table, "<font_size=60><b>1</b></font_size>", 0, 3, 1, 1, 1);
   create_button(table, "<font_size=60><b>2</b></font_size>", 1, 3, 1, 1, 2);
   create_button(table, "<font_size=60><b>3</b></font_size>", 2, 3, 1, 1, 3);
   //create_button(table, "-", 3, 4, 1, 1, ID_MINUS);


   create_button(table, "<font_size=60><b>Clear</b></font_size>", 0, 4, 1, 1, ID_CLEAR);
   create_button(table, "<font_size=60><b>0</b></font_size>", 1, 4, 1, 1, 0);
   create_button(table, "<font_size=60><b>Move</b></font_size>", 2, 4, 1, 1, ID_EQUAL);

   /* Bg-1 */
   //Evas_Object *bg = elm_bg_add(parent);
   //elm_bg_color_set(bg, 54, 184, 207);
   //my_table_pack(table, bg, 0, 1, 4, 1);

   /* Entry-1 */
   //Evas_Object *entry = elm_entry_add(parent);
   //elm_entry_single_line_set(entry, EINA_TRUE);
   //elm_entry_entry_insert(entry, "Entry-1");
   //elm_object_part_text_set(entry, "elm.guide", "Input Text");
   //my_table_pack(table, entry, 0, 1, 4, 1);

   /* Label*/
   //Evas_Object *label = elm_label_add(parent);
   //elm_object_text_set(label, "<font_size=40><color=#FFFFFFFF><align=left><b>Channel</b></align></color></font_size>");
   //my_box_pack(box, label, 1.0, 0.0, -1.0, 0.5);

   /* Genlist */
   //Evas_Object *genlist = elm_genlist_add(parent);
   //my_box_pack(box, genlist, 1.0, 1.0, -1.0, -1.0);


   /* Create item class */
   //Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();
   //itc->item_style = "end_icon";
   //itc->func.text_get = gl_text_get_cb;
   //itc->func.del = gl_del_cb;

   /* Item add */
   /*for(int i=0; i < 10 ; i++)
   {
      item_data_s *id = calloc(sizeof(item_data_s), 1);
      id->index = i;
      id->item = elm_genlist_item_append(genlist, itc, id, NULL, ELM_GENLIST_ITEM_NONE, NULL, id);
   }*/
   //elm_genlist_item_class_free(itc);

   //evas_object_show(table);
   return grid;
}


void
sub_view2_cb(void *data, Evas_Object *obj, void *event_info)
{
   Evas_Object *scroller, *layout;
   Evas_Object *nf = data;
   scroller = elm_scroller_add(nf);
   layout = create_button_view2(scroller, nf);
   elm_object_content_set(scroller, layout);
   elm_naviframe_item_push(nf, "<b>Remote Control</b>", NULL, NULL, scroller, NULL);
}
