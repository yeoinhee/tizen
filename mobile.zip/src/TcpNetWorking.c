#include "mobile.h"
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/stat.h>
#include <unistd.h>

struct sockaddr_in server;


char * SendMessage2(char *data,int sock)
{

   char * server_reply = NULL;

   if(sock==-1) // 이전 데이터를 이용
   {

   }
   else
   {
     // sock_b = sock;
   }



   {
      // Send some data

	   //dlog_print(DLOG_DEBUG,"socksock",sock_b);

	  dlog_print(DLOG_DEBUG,"taggg",data);


	  if(strstr(data,"Request")!=NULL)
	  {
		  if(send(sock, data, strlen(data), 0) <0)
		       {
		          puts("Send failed");
		          dlog_print(DLOG_DEBUG,LOG_TAG,"rrrrrr33");
		       }

	     	  dlog_print(DLOG_DEBUG,LOG_TAG,"aaaaaaaaaa");

	     	  server_reply = (char*)calloc(2000,sizeof(char));

	     	  if(recv(sock,server_reply, 2000,0)<0)    // Get file list from       num/file1/file2/file3/file4... /port번호
	            {
	                 puts("recv failed");
	               dlog_print(DLOG_DEBUG,LOG_TAG,"1111recv failed");
	             }
	  }
	  else
	  {
      if(send(sock, data, strlen(data), 0) <0)
      {
         puts("Send failed");
         dlog_print(DLOG_DEBUG,LOG_TAG,"rrrrrr33");
      }


      if(strcmp(data,"getList") == 0 )
      {
         server_reply = (char*)calloc(2000,sizeof(char));

         // List를 받아와야 하는 경우.
         if(recv(sock,server_reply, 2000,0)<0)    // Get file list from       num/file1/file2/file3/file4... /port번호
         {
            puts("recv failed");
            dlog_print(DLOG_DEBUG,LOG_TAG,"recv failed");
         }

      }

	  }

      dlog_print(DLOG_DEBUG,LOG_TAG,"Success!!!!!");
   }

   //return 0;
   return server_reply;
}


void InitSocket(int * sock)
{

      //sock = (int *) malloc(sizeof(int));
      // 동적할당 한후에, sock할당


      *sock = socket(AF_INET,SOCK_STREAM,0);
      if(*sock == -1)
      {
         printf("Could not create socket");
         dlog_print(DLOG_DEBUG,LOG_TAG,"rrrrrr11");
      }
      puts("Socket created");

      server.sin_addr.s_addr = inet_addr("192.168.43.79");
      server.sin_family = AF_INET;
      server.sin_port = htons(8888);

      //sock_b = *sock;

      // Connect to remote server
      if(connect(*sock,(struct sockaddr *)&server, sizeof(server))<0)
      {
         perror("Connect failed. Error");
         dlog_print(DLOG_DEBUG,LOG_TAG,"rrrrrr22");
      }
      puts("Connected");
}

void CloseSocket(int * sock)
{
   close(*sock);

   //free(sock);
}
