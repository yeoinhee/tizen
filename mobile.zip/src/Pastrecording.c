#pragma once
#include "mobile.h"
#include <stdio.h>
#include <string.h>
#include <langinfo.h>
#include <math.h>

#define DATE_FORMAT "%d/%b/%Y"
#define DATE_LAYOUT "date_layout"


char buffString[1000] = {0,};

char * filelist = NULL;
extern int * sock;


int numlength = 3;

#define TIME_12_FORMAT "%I:%M %p"
#define TIME_12_LAYOUT "time_layout"

#define TIME_24_FORMAT "%H:%M"
#define TIME_24_LAYOUT "time_layout_24hr"
const char *items[] = {"0604_1.avi" , "0604_2.avi" , "0604_3.avi" };


char ** myitems = NULL;

int myportnum = 9000;

Evas_Object *datetime, *datatime2;
typedef struct item_data
{
	int index;
	Elm_Object_Item *item;
	Evas_Object *nf;
	char text[40];
} item_data_s;

item_data_s *id;
Evas_Object *list;
Evas_Object *genlist;
struct tm saved_time;
int items_num;
Elm_Object_Item *it;

typedef struct datetimedata {
	Evas_Object *nf;
	Evas_Object *datetime;
	Evas_Object *popup;
	Evas_Object *button1;
	Evas_Object *button2;
	Evas_Object *button3;
	struct tm saved_time;
} datetimedata_s;

static void
btn_back_cb(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *nf = data;
	elm_naviframe_item_pop(nf);
}

void
dismissed_cb(void *data, Evas_Object *obj, void *event_info)
{
    evas_object_del(obj);
}

static void popup_block_clicked(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = data;
	evas_object_del(obj);
	elm_object_text_set(ad->label5, "Block Clicked");
}
static void make_popup_text(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = data;
	ad->popup = elm_popup_add(ad->grid);
	elm_popup_align_set(ad->popup, ELM_NOTIFY_ALIGN_FILL, 1.0);
	evas_object_size_hint_weight_set(ad->popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	elm_object_text_set(ad->popup, "Text popup - timeout of 3 sec is set.");
	elm_popup_timeout_set(ad->popup, 3.0);
	//evas_object_smart_callback_add(ad->popup, "timeout", popup_timeout, ad);
	  evas_object_smart_callback_add(ad->popup, "block,clicked", popup_block_clicked, ad);
	evas_object_show(ad->popup);
	ad->popupNum = 1;
}
static void popup_btn1_clicked(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = data;
	if (ad->popupNum == 4) {
	const char *input;
	Eina_Strbuf *str;

    /* use eina_strbuf here for safe string allocation and formatting */
	input = elm_entry_entry_get(ad->entry1);
	str = eina_strbuf_new();
	eina_strbuf_append_printf(str, "Input: '%s'", input);
	elm_object_text_set(ad->label5, eina_strbuf_string_get(str));
	eina_strbuf_free(str);
	}
	else{
		  elm_object_text_set(ad->label5, "Button 1 clicked.");
	}

    /* Destroy the popup AFTER reading from its child entry */
	evas_object_del(ad->popup);
	ad->popup = NULL;
	/* Entry will be deleted when the popup is deleted (child widget) */
	ad->entry1 = NULL;
}
static void popup_btn2_clicked(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = data;
	evas_object_del(ad->popup);
	elm_object_text_set(ad->label5, "Button-2 Clicked");
}
static void popup_btn3_clicked(void *data, Evas_Object *obj, void *event_info)
{
	appdata_s *ad = data;

	evas_object_del(ad->popup);
	elm_object_text_set(ad->label5, "Button-3 Clicked");
}
static void make_popup_text_1button(void *data, Evas_Object *obj, void *event_info)
{
    Evas_Object *btn;
    appdata_s *ad = data;
    /* popup */
    ad->popup = elm_popup_add(ad->grid);
    elm_popup_align_set(ad->popup, ELM_NOTIFY_ALIGN_FILL, 1.0);
    evas_object_smart_callback_add(ad->popup, "block,clicked", popup_block_clicked, ad);
    evas_object_size_hint_weight_set(ad->popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
    elm_object_text_set(ad->popup, "1Button popup");

    /* ok button */
    btn = elm_button_add(ad->popup);
    elm_object_text_set(btn, "OK");
    elm_object_part_content_set(ad->popup, "button1", btn);
    evas_object_smart_callback_add(btn, "clicked", popup_btn1_clicked, ad);
    evas_object_show(ad->popup);
    ad->popupNum = 2;
}
static void make_popup_text_3button(void *data, Evas_Object *obj, void *event_info)
{
	 Evas_Object *btn;
	 appdata_s *ad = data;
	 /* popup */
	 ad->popup = elm_popup_add(ad->grid);
	 elm_popup_align_set(ad->popup, ELM_NOTIFY_ALIGN_FILL, 1.0);
	 evas_object_smart_callback_add(ad->popup, "block,clicked", popup_block_clicked, ad);
	 evas_object_size_hint_weight_set(ad->popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	 elm_object_text_set(ad->popup, "3Button popup");
	 /* ok button */
	 btn = elm_button_add(ad->popup);
	 elm_object_text_set(btn, "OK");
	 elm_object_part_content_set(ad->popup, "button1", btn);
	 evas_object_smart_callback_add(btn, "clicked", popup_btn1_clicked, ad);
	 /* cancel button */
	 btn = elm_button_add(ad->popup);
	 elm_object_text_set(btn, "Cancel");
	 elm_object_part_content_set(ad->popup, "button2", btn);
	 evas_object_smart_callback_add(btn, "clicked", popup_btn2_clicked, ad);
	 /* close button */
	 btn = elm_button_add(ad->popup);
	 elm_object_text_set(btn, "Close");
	 elm_object_part_content_set(ad->popup, "button3", btn);
	 evas_object_smart_callback_add(btn, "clicked", popup_btn3_clicked, ad);
	 evas_object_show(ad->popup);
	 ad->popupNum = 3;
}
static void make_popup_input_text(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *btn;
	appdata_s *ad = data;
	Evas_Object *entry;
	/* popup */
	ad->popup = elm_popup_add(ad->grid);
	elm_popup_align_set(ad->popup, ELM_NOTIFY_ALIGN_FILL, 1.0);
	evas_object_smart_callback_add(ad->popup, "block,clicked", popup_block_clicked, ad);
	evas_object_size_hint_weight_set(ad->popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	elm_object_part_text_set(ad->popup, "title,text", "Input Text");
	/* entry */
	entry = elm_entry_add(ad->popup);
	evas_object_size_hint_weight_set(entry, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	evas_object_size_hint_align_set(entry, EVAS_HINT_FILL, EVAS_HINT_FILL);
	elm_object_part_content_set(ad->popup, "elm.swallow.content" , entry);
	evas_object_show(entry);
	ad->entry1 = entry;
	/* OK button */
	btn = elm_button_add(ad->popup);
	elm_object_text_set(btn, "OK");
	elm_object_part_content_set(ad->popup, "button1", btn);
	evas_object_smart_callback_add(btn, "clicked", popup_btn1_clicked, ad);
	/* Cancel button */
	btn = elm_button_add(ad->popup);
	elm_object_text_set(btn, "Cancel");
	elm_object_part_content_set(ad->popup, "button2", btn);
	evas_object_smart_callback_add(btn, "clicked", popup_btn2_clicked, ad);
	evas_object_show(ad->popup);
	ad->popupNum = 4;
}
static void list_item_clicked(void *data, Evas_Object *obj, void *event_info)
{
	int index = (int)data;
	Elm_Object_Item *it = event_info;
	const char *item_text = elm_object_item_text_get(it);
	char buf[PATH_MAX];
	sprintf(buf, "%d - %s", index, item_text);
	dlog_print(DLOG_INFO, "tag", "%s", buf);
	//btn_past_record_view(data,obj,event_info);
	//make_popup_text_3button(ad,list,event_info);
	 //evas_object_smart_callback_add(btn, "clicked", make_popup_text_3button, ad);
	/*Evas_Object *btn1,*btn2;
	Evas_Object *label;
	popup=elm_popup_add(parent);
	elm_popup_align_set(popup,ELM_N)*/

}
static void popup_closed_cb(void *data, Evas_Object *obj, void *event_info) {

   if (!obj)
      return;
   evas_object_del(popup);
   elm_popup_dismiss(popup);
}
static void list_item2_clicked(void *data, Evas_Object *obj, void *event_info)
{
	item_data_s *id = data;
	int index=id->index;
	char *item_text= elm_object_text_get(id->text);
	char buf[PATH_MAX];
	sprintf(buf, "%s",id->text);

	strcpy(buffString,buf);

	char requestLink[1000];

	sprintf(requestLink,"Request/%s",buffString);

	char * tmpString = SendMessage2(requestLink,*sock);

	strcpy(buffString,tmpString);

	dlog_print(DLOG_INFO, "tag2", "%s", buf);

	Evas_Object *nf=id->nf;

	dlog_print(DLOG_INFO, "tag", "make!");
	popup=elm_popup_add(nf);
	elm_popup_align_set(popup, ELM_NOTIFY_ALIGN_FILL, 0.5);
	evas_object_size_hint_weight_set(popup, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	Evas_Object *content;

	//elm_object_content_set(popup, content);

	Evas_Object *button1;
	Evas_Object *button2, *label;
	label = elm_label_add(popup);
	evas_object_size_hint_align_set(label, EVAS_HINT_FILL, EVAS_HINT_FILL);
	elm_object_text_set(label,
	"<font_size=40><align=center>기록을 확인하시겠습니까?</align></font size>");
	elm_object_content_set(popup, label);

	/* Create the 2 buttons */
	button1 = elm_button_add(popup);
	elm_object_style_set(button1, "popup");
	elm_object_text_set(button1, "OK");
	elm_object_part_content_set(popup, "button1", button1);

	button2 = elm_button_add(popup);
	elm_object_style_set(button2, "popup");
	elm_object_text_set(button2, "Cancel");
	elm_object_part_content_set(popup, "button2", button2);

	/* Add a callback function to popup */
	eext_object_event_callback_add(popup, EEXT_CALLBACK_BACK, eext_popup_back_cb, NULL);
	evas_object_smart_callback_add(button1, "clicked", btn_past_record_view, nf);
	evas_object_smart_callback_add(button2, "clicked", popup_closed_cb, nf);
	evas_object_smart_callback_add(popup, "block,clicked", popup_block_clicked, nf);
	evas_object_show(button1);
	evas_object_show(button2);
	evas_object_show(popup);

}
static char*
gl_text_get_cb(void *data, Evas_Object *obj, const char *part)
{
	item_data_s *id = data;
	if (!strcmp(part, "elm.text")) {
		return strdup(myitems[id->index]);
	}
return NULL;
}
static void gl_del_cb(void *data, Evas_Object *obj)
{
	item_data_s *id = data;
	free(id);
}
static void _hoversel_item_cb()
{

}
static Evas_Object*
create_button_view3(Evas_Object *parent, Evas_Object *nf)
{
	Evas_Object *btn, *img, *grid,*nf2;
	/* Label*/
	Evas_Object *label;
	nf2=elm_naviframe_add(parent);
		elm_object_part_content_set(parent, "elm.swallow.content", nf2);
		elm_object_content_set(parent, nf2);

		grid = elm_grid_add(parent);
		elm_grid_size_set(grid, 480, 800);
		evas_object_size_hint_weight_set(grid, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set(grid, EVAS_HINT_FILL, EVAS_HINT_FILL);
		elm_bg_color_set(grid, 255, 255, 255);
		evas_object_show(grid);
		Evas_Object *bg = elm_bg_add(grid);
		elm_grid_pack(grid, bg, 0, 80, 480, 800);
		elm_bg_color_set(bg, 251, 251, 251);
		evas_object_show(bg);
		//label = elm_label_add(grid);
		//elm_object_text_set(label, "<color=#FFFFFFFF><font_size=60><b><align=center>Past Recording </align></b></font_size></color>");
		//elm_grid_pack(grid,label,200,50,70,70);
		//evas_object_show(label);
		//elm_win_resize_object_add(parent, box);
		//elm_object_content_set(nf, box);
		//evas_object_show(box);

		/* icon_reorder style */
		btn = elm_button_add(grid);
		elm_object_style_set(btn, "icon_reorder");
		//elm_object_text_set(btn,"<align=center>text</align>");
		evas_object_smart_callback_add(btn, "clicked", btn_back_cb, nf);
		//elm_box_align_set(box,0.5,0.5);
		elm_grid_pack(grid,btn,200,10,70,70);
		evas_object_show(btn);
		//elm_box_pack_end(box, btn);

		/* List */
		/*const char *items[] = { "0604_1.avi" , "0604_2.avi" , "0604_3.avi" };
		list = elm_list_add(grid);
		elm_list_mode_set(list,ELM_LIST_COMPRESS);
		evas_object_smart_callback_add(list, "selected", NULL, NULL);

		for(int i=0; i < 3; i++)
			{
			elm_list_item_append(list, items[i], NULL, NULL,list_item_clicked, (void*)i);

			}
		elm_list_go(list);
		evas_object_smart_callback_add(list, "selected", list_selected_cb, NULL);
		elm_grid_pack(grid, list, 41, 180, 400,505);
		evas_object_show(list);*/
		/*btn = elm_button_add(grid);
		elm_object_text_set(btn,"<b>View</b>");
		evas_object_show(btn);
		evas_object_smart_callback_add(btn,"clicked",btn_past_record_view,nf);
		elm_grid_pack(grid,btn,65,700,350,80);
		evas_object_show(btn);*/

		/* Genlist */
		genlist = elm_genlist_add(grid);
		evas_object_size_hint_weight_set(genlist,EVAS_HINT_EXPAND,EVAS_HINT_EXPAND);
		elm_grid_pack(grid, genlist, 41, 180, 400,505);


		/* Create item class */
		Elm_Genlist_Item_Class *itc = elm_genlist_item_class_new();
	    itc->item_style = "end_icon";
	    itc->func.text_get = gl_text_get_cb;
	    itc->func.del = gl_del_cb;


	    /* Item add */
	   for(int i=0; i < numlength ; i++)
	    {
	    	id = calloc(sizeof(item_data_s), 1);
	    	id->index = i;
	    	strcpy(id->text,myitems[i]);
	    	it = elm_genlist_item_append(genlist, itc, id, NULL, NULL, list_item2_clicked, id);
	    	id->item = it;
	    	id->nf=nf;
	    }
	   //dlog_print(DLOG_INFO, "tag2", "%s", id->text);
	    elm_genlist_realized_items_update(genlist);
	    evas_object_show(genlist);


	    elm_genlist_item_class_free(itc);

		/*Evas_Object * hoversel=elm_hoversel_add(grid);

		elm_object_text_set(hoversel,"<color=#FFFFFFFF>text</color>");
		elm_hoversel_horizontal_set(hoversel, EINA_FALSE);
		elm_hoversel_hover_parent_set(hoversel, grid);
		elm_hoversel_hover_begin(hoversel);
		elm_hoversel_hover_end(hoversel);


		Eina_Bool expanded;
		expanded = elm_hoversel_expanded_get(hoversel);

		Elm_Object_Item *it;
		it = elm_hoversel_item_add(hoversel, "1월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "2월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "3월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "4월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "5월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "6월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "7월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "8월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "9월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "10월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "11월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		it = elm_hoversel_item_add(hoversel, "12월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		//Eina_List *items;
		//items = elm_hoversel_items_get(hoversel);
		//it = elm_hoversel_item_add(hoversel, "12월", NULL, ELM_ICON_NONE, _hoversel_item_cb, NULL);
		//elm_object_item_part_text_set(it, "default", "New label");
		//elm_hoversel_clear(hoversel);
		elm_grid_pack(grid,hoversel,100,150,350,50);
		evas_object_show(hoversel);
		*/



	/*	time_t local_time = time(NULL);
		char buff[200] = {0,};
		struct tm *time_info = localtime(&local_time);
		saved_time = *time_info;
		char*format;


		elm_naviframe_item_push(nf, "Datetime", NULL, NULL, grid, NULL);
		datetime = elm_datetime_add(grid);
		format=evas_object_data_get(parent,"format");

		evas_object_size_hint_align_set(datetime, EVAS_HINT_FILL, EVAS_HINT_FILL);
		elm_object_part_text_set(datetime, "title,text","Date_Picker");
		elm_object_style_set(datetime, DATE_LAYOUT);
*/
		/* Set a format for datetime */
	//	elm_datetime_format_set(datetime, DATE_FORMAT);

		/* Get a current local time to set as datetime value */
	//	time(NULL);

	//	time_info = localtime(&local_time);
	//	elm_datetime_value_set(datetime, &saved_time);

		//sprintf(buf, "%s%04d-%02d-%02d%s",time_info->tm_year + 1900, time_info->tm_mon + 1,  time_info->tm_mday);
		//elm_object_text_set(label,buf);
		//dlog_print(DLOG_INFO, "user_tag", buf);

	/*	elm_grid_pack(grid,datetime,65,200,350,50);
		evas_object_show(datetime);


		datatime2 = elm_datetime_add(grid);
		format=evas_object_data_get(parent,"format");

		evas_object_size_hint_align_set(datatime2, EVAS_HINT_FILL, EVAS_HINT_FILL);
		elm_object_part_text_set(datatime2, "title,text","Time_12_Picker");
		elm_object_style_set(datatime2, TIME_12_LAYOUT);
*/
		/* Set a format for datetime */
	//	elm_datetime_format_set(datatime2, "%d/%b/%Y %I:%M %p");

		/* Get a current local time to set as datetime value */
	//	time(NULL);

	//	time_info = localtime(&local_time);
	//	elm_datetime_value_set(datatime2, &saved_time);

		//sprintf(buf, "%s%04d-%02d-%02d%s",time_info->tm_year + 1900, time_info->tm_mon + 1,  time_info->tm_mday);
		//elm_object_text_set(label,buf);
		//dlog_print(DLOG_INFO, "user_tag", buf);
	/*	elm_grid_pack(grid,datatime2,65,500,350,50);

		evas_object_show(datatime2);

		btn = elm_button_add(grid);
		elm_object_text_set(btn,"<b>View</b>");
		evas_object_show(btn);
		evas_object_smart_callback_add(btn,"clicked",datetime_cb,nf);
		elm_grid_pack(grid,btn,65,700,350,80);
		evas_object_show(btn);
*/
		return grid;
}

void
datetime_cb(void *data, Evas_Object *obj, void *event_info)
{
	char buff[200]={0,};
	char buff2[200]={0,};
	//time_t local_time = time(NULL);
	elm_datetime_value_get(datetime, &saved_time);
	strftime(buff,200, DATE_FORMAT,&saved_time);
	dlog_print(DLOG_INFO,"user_tag",buff);

	elm_datetime_value_get(datatime2, &saved_time);
	strftime(buff2,200, TIME_12_FORMAT,&saved_time);
	dlog_print(DLOG_INFO,"user2_tag",buff2);

	btn_past_record_view(data,obj,event_info);
}
void
sub_view3_cb(void *data, Evas_Object *obj, void *event_info)
{


	Evas_Object *scroller, *layout;
	Evas_Object *nf = data;
	scroller = elm_scroller_add(nf);

	filelist = SendMessage2("getList",*sock); // TO get file list from server

	dlog_print(DLOG_DEBUG,"TTTTTT",filelist);

	int nnn = atoi(strtok(filelist,"/"));
	numlength = nnn;

	myitems = (char **) malloc(sizeof(char*) * nnn);


	for(int i=0;i<nnn;i++)
	{
		myitems[i] = (char * ) malloc(sizeof(char) * 200);

		strcpy(myitems[i],strtok(NULL,"/"));

		dlog_print(DLOG_DEBUG,"receive file path",myitems[i]);
	}

	myportnum = atoi(strtok(NULL,"/"));


	layout = create_button_view3(scroller, nf);




	elm_object_content_set(scroller, layout);
	elm_naviframe_item_push(nf, "<b>Past Recording</b>", NULL, NULL, scroller, NULL);

	evas_object_show(nf);

}
