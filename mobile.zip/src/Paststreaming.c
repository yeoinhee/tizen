#pragma once
#include "mobile.h"
#include <stdio.h>
#include <string.h>
#include <EWebKit.h>


extern int * sock;

extern int myportnum;

extern char buffString[1000];

static void
my_table_pack(Evas_Object * table, Evas_Object * child, int x, int y, int w, int h)
{
	evas_object_size_hint_align_set(child,EVAS_HINT_FILL,EVAS_HINT_FILL);
	evas_object_size_hint_weight_set(child,EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
	elm_table_pack(table,child,x,y,w,h);
	evas_object_show(child);
}

static i18n_ucalendar_h
create_time(char *tzid)
{
	i18n_ucalendar_h ucal;
	i18n_uchar *_tzid = (i18n_uchar*)calloc(strlen(tzid) + 1, sizeof(i18n_uchar));

	// converts 'tzid' to unicode string
	i18n_ustring_copy_ua(_tzid, tzid);
	// gets length of '_tzid'
	int len = i18n_ustring_get_length(_tzid);
	// creates i18n_ucalendar_h
	int ret = i18n_ucalendar_create(_tzid, len, "en_US", I18N_UCALENDAR_TRADITIONAL, &ucal);
	if (ret != 0)
	{
		dlog_print(DLOG_ERROR, LOG_TAG, "i18n_ucalendar_create() failed with err = %d", ret);
		return NULL;
	}

	    return ucal;
}

static void update(appdata_s *ad)
{
	int year, month, day, hour, minute, second;
	i18n_udate udate;
	char buf[256];
	int diff;

    /* Current time */
	i18n_ucalendar_get_now(&udate);
	i18n_ucalendar_set_milliseconds(ad->ucal, udate);
	i18n_ucalendar_get(ad->ucal, I18N_UCALENDAR_YEAR, &year);
	i18n_ucalendar_get(ad->ucal, I18N_UCALENDAR_MONTH, &month);
	i18n_ucalendar_get(ad->ucal, I18N_UCALENDAR_DATE, &day);
	i18n_ucalendar_get(ad->ucal, I18N_UCALENDAR_HOUR_OF_DAY, &hour);
	i18n_ucalendar_get(ad->ucal, I18N_UCALENDAR_MINUTE, &minute);
	i18n_ucalendar_get(ad->ucal, I18N_UCALENDAR_SECOND, &second);
	snprintf(buf, sizeof(buf), "%d/%02d/%02d %02d:%02d:%02d", year, month + 1, day, hour, minute, second);
	elm_object_text_set(ad->label2, buf);
}

static void
btn_back_cb(void *data, Evas_Object *obj, void *event_info)
{
	Evas_Object *nf = data;
	elm_naviframe_item_pop(nf);
}

static Evas_Object*
create_button_view4(Evas_Object *parent, Evas_Object *nf){
		Evas_Object *btn, *img, *box,*nf2;

		box = elm_box_add(parent);
		evas_object_size_hint_weight_set(box, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set(box, EVAS_HINT_FILL, EVAS_HINT_FILL);

		/* icon_reorder style */
		btn = elm_button_add(box);
		elm_object_style_set(btn, "icon_reorder");
		evas_object_smart_callback_add(btn, "clicked", btn_back_cb, nf);
		elm_box_align_set(box,0.5,0.5);
		evas_object_show(btn);
		elm_box_pack_end(box, btn);

		//////////////


		Evas_Object *table = elm_table_add(parent);
		elm_table_homogeneous_set(table,EINA_TRUE);
		elm_table_padding_set(table, 5 * elm_config_scale_get(), 10 * elm_config_scale_get());
		evas_object_size_hint_weight_set(table, EVAS_HINT_EXPAND,EVAS_HINT_EXPAND);
		evas_object_size_hint_align_set(table,EVAS_HINT_FILL,EVAS_HINT_FILL);
		elm_box_pack_end(box,table);

		evas_object_show(table);



		//char buf[1000] ;

		//sprintf(buf,"http://10.210.61.109:%d/%s",myportnum,buffString);

		char rebuf[1000];

		sprintf(rebuf,"http://192.168.43.79:%s",buffString);

		Evas * evas = evas_object_evas_get(parent);
		Evas_Object * web_view = ewk_view_add(evas);

		//ewk_view_url_set(web_view,"http://10.210.61.109:8555/test.mjpeg");

		ewk_view_url_set(web_view,rebuf);

		evas_object_size_hint_align_set(web_view,EVAS_HINT_FILL,EVAS_HINT_FILL);
		evas_object_size_hint_weight_set(web_view,EVAS_HINT_EXPAND,EVAS_HINT_EXPAND);
		my_table_pack(table,web_view,0,2,5,10);
		evas_object_show(web_view);

		return box;
}

void
btn_past_record_view(void * data, Evas_Object *obj, void *event_info)
{
	evas_object_del(popup);
	elm_popup_dismiss(popup);
	Evas_Object *scroller, *layout;
	Evas_Object *nf = data;
	scroller = elm_scroller_add(nf);
	layout = create_button_view4(scroller, nf);
	elm_object_content_set(scroller, layout);


	//// 위에서 가져온 파일경로를 바탕으로 데이터를 보낸다.


	elm_naviframe_item_push(nf, "<b>Recording</b>", NULL, NULL, scroller, NULL);

	struct tm stime;


	evas_object_show(nf);
}
