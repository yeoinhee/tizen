#ifndef __mobile_H__
#define __mobile_H__

#include <app.h>
#include <Elementary.h>
#include <system_settings.h>
#include <efl_extension.h>
#include <app_preference.h>
#include <stdlib.h>
#include <dlog.h>
#include <utils_i18n.h>

#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "mobile"

#if !defined(PACKAGE)
#define PACKAGE "org.example.mobile"
#endif
#define ICON_DIR "/opt/usr/apps/org.example.mobile/res/images"

#define IPADDR "10.210.61.109"

typedef struct appdata {
   Evas_Object *win;
   Evas_Object *nf;

   Evas_Object *conform;
   Evas_Object *label;
   Evas_Object *label1;
   Evas_Object *label2;
   Evas_Object *label3;
   Evas_Object *label4;
   Evas_Object *label5;
   Evas_Object *check1;
   Evas_Object *check2;
   Evas_Object *check3;
   Evas_Object *check4;
   Evas_Object *slide;
   Ecore_Timer *timer;
   Evas_Object *popup;
   Evas_Object *grid;
   Evas_Object *box;
   int popupNum;
   char *tzid;
   i18n_ucalendar_h ucal;
   Evas_Object *entry1;
   Evas_Object *spinner1;

} appdata_s;
//const char *string_key = "string_key";
appdata_s *ad;

Evas_Object *popup;



static void popup_closed_cb(void *data, Evas_Object *obj, void *event_info);
static Evas_Object*
create_button_view4(Evas_Object *parent, Evas_Object *nf);
static void btn_read_cb(void *data, Evas_Object *obj, void *event_info);
void
datetime_cb(void *data, Evas_Object *obj, void *event_info);
void
btn_past_record_view(void * data, Evas_Object *obj, void *event_info);
void sub_view1_cb(void *data, Evas_Object *obj, void *event_info);
void sub_view2_cb(void *data, Evas_Object *obj, void *event_info);
void sub_view3_cb(void *data, Evas_Object *obj, void *event_info);

char * SendMessage2(char *data,int sock);
void InitSocket(int *sock);
void CloseSocket(int *sock);

#endif /* __mobile_H__ */
