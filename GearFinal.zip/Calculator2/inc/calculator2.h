/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd
 *
 * Licensed under the Flora License, Version 1.1 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://floralicense.org/license/
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


#pragma once
#if !defined(_CALC_H)
#define _CALC_H

#if !defined(PACKAGE)
#define PACKAGE "org.example.calculator2"
#endif

#ifdef  LOG_TAG
#undef  LOG_TAG
#endif
#define LOG_TAG "calculator2"




/**
 *
 *
 * Each value the button.
 */
typedef enum {
	KEY_VAL_AFTER_RESULT = -1,
	KEY_VAL_ZERO = 0,
	KEY_VAL_ONE,
	KEY_VAL_TWO,
	KEY_VAL_THREE,
	KEY_VAL_FOUR,
	KEY_VAL_FIVE,
	KEY_VAL_SIX,
	KEY_VAL_SEVEN,
	KEY_VAL_EIGHT,
	KEY_VAL_NINE,
	KEY_VAL_RE,	//reset
	KEY_VAL_VOLUP,
	KEY_VAL_VOLDOWN,
	KEY_VAL_MUTE,
	KEY_VAL_POWER,
	KEY_VAL_MOVE,
	KEY_VAL_CHANNELUP,
	KEY_VAL_CHANNELDOWN,
	KEY_VAL_POWEROFF,
} key_value;

/**
 * Enum value for the type of the button.
 */
typedef enum {
	KEY_TYPE_EX = 0,
	KEY_TYPE_NUM,
	//KEY_TYPE_OP,
} key_type;

/**
 * Variables for the information of the button.
 */
typedef struct {
	Evas_Object *button;
	key_type button_type;
	key_value button_val;
	const char *button_val_str;
	const char *pair_value;
	const char *button_name;
} button_info_s;

#include"func.h"

#endif
