char * SendMessage2(char *data,int sock);
void InitSocket(int * sock);
void CloseSocket(int * sock);
