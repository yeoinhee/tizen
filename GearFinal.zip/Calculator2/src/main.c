/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd
 *
 * Licensed under the Flora License, Version 1.1 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://floralicense.org/license/
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <Elementary.h>
#include <system_settings.h>
#include <efl_extension.h>
#include <app.h>
#include <dlog.h>
#include "calculator2.h"
#include "view.h"
#include "data.h"
#include "func.h"
#include <sensor.h>
#include <pthread.h>


int *sock;

typedef struct appdata {
	Evas_Object *win;
	Evas_Object *conform;
	Evas_Object *label0;
	Evas_Object *label1;
	Evas_Object *label2;
} appdata_s;

typedef struct _sensor_info {
	sensor_h sensor; /**< Sensor handle */
	sensor_listener_h sensor_listener;
} sensorinfo;

static sensorinfo sensor_info;

float zmax = 0.f;
float ymax = 0.f;

int timer_count = 0;



static void _new_sensor_value(sensor_h sensor, sensor_event_s *sensor_data,
		void *user_data) {
	if (sensor_data->value_count < 3)
		return;
	char buf[200];
	sprintf(buf, "Value - X : %0.1f / Y : %0.1f / Z : %0.1f",
			sensor_data->values[0], sensor_data->values[1],
			sensor_data->values[2]);

	//SendMessage2(buf,*sock);

	if (ymax < sensor_data->values[1])
		ymax = sensor_data->values[1];
	if (zmax < sensor_data->values[2])
		zmax = sensor_data->values[2];

	if ((sensor_data->values[2] >= 7.f && sensor_data->values[2] <= 12.f)) //||(sensor_data->values[2] >= 7.f && sensor_data->values[2] <= 12.f) )
	{
		if (zmax >= 14.f) {
			SendMessage2("PowerOn", *sock);
			zmax = 0.f;
		}


		zmax = 0.f;
		ymax = 0.f;

	}

	if ((sensor_data->values[1] >= 7.f && sensor_data->values[1] <= 12.f)) //||(sensor_data->values[2] >= 7.f && sensor_data->values[2] <= 12.f) )
		{
			if (ymax >= 14.f) {
				SendMessage2("PowerOff", *sock);
				ymax = 0.f;
			}



			ymax  = 0.f;
			zmax  = 0.f;
		}


}

static void start_acceleration_sensor(appdata_s *ad) {
sensor_error_e err = SENSOR_ERROR_NONE;
sensor_get_default_sensor(SENSOR_ACCELEROMETER, &sensor_info.sensor);
err = sensor_create_listener(sensor_info.sensor, &sensor_info.sensor_listener);
sensor_listener_set_event_cb(sensor_info.sensor_listener, 100,
		_new_sensor_value, ad);
sensor_listener_start(sensor_info.sensor_listener);
}


void * start(void *data)
{
	start_acceleration_sensor(data);
}



#define CALC_BUTTON 19
/**
 * Pre-declared values of the button.
 */
static button_info_s BUTTON_PARAM[19] = {
	{NULL, KEY_TYPE_NUM, KEY_VAL_ZERO, "0", NULL, "zero_button"},
	{NULL, KEY_TYPE_NUM, KEY_VAL_ONE, "1", NULL, "one_button"},
	{NULL, KEY_TYPE_NUM, KEY_VAL_TWO, "2", NULL, "two_button"},
	{NULL, KEY_TYPE_NUM, KEY_VAL_THREE, "3", NULL, "three_button"},
	{NULL, KEY_TYPE_NUM, KEY_VAL_FOUR, "4", NULL, "four_button"},
	{NULL, KEY_TYPE_NUM, KEY_VAL_FIVE, "5", NULL, "five_button"},
	{NULL, KEY_TYPE_NUM, KEY_VAL_SIX, "6", NULL, "six_button"},
	{NULL, KEY_TYPE_NUM, KEY_VAL_SEVEN, "7", NULL, "seven_button"},
	{NULL, KEY_TYPE_NUM, KEY_VAL_EIGHT, "8", NULL, "eight_button"},
	{NULL, KEY_TYPE_NUM, KEY_VAL_NINE, "9", NULL, "nine_button"},
	{NULL, KEY_TYPE_EX, KEY_VAL_RE, "re", NULL, "reset_button"},
	{NULL, KEY_TYPE_EX, KEY_VAL_VOLUP, " ", NULL, "volup_button"},
	{NULL, KEY_TYPE_EX, KEY_VAL_VOLDOWN, " ", NULL, "voldown_button"},
	{NULL, KEY_TYPE_EX, KEY_VAL_MUTE, " ", NULL, "mute_button"},
	{NULL, KEY_TYPE_EX, KEY_VAL_POWER, " ", NULL, "power_button"},
	{NULL, KEY_TYPE_EX, KEY_VAL_MOVE, " ", NULL, "move_button"},
	{NULL, KEY_TYPE_EX, KEY_VAL_CHANNELUP, "+", NULL,"channelup_button"},
	{NULL, KEY_TYPE_EX, KEY_VAL_CHANNELDOWN, "-", NULL, "channeldown_button"},
	{NULL, KEY_TYPE_EX, KEY_VAL_POWEROFF, " ", NULL, "poweroff_button"},
};

/**
 * @brief Adds a number to the displayed formula.
 * @param[in] btn_info Information of the pressed button
 */


///










///////////




static void _add_number(button_info_s *btn_info)
{
	char *text = NULL;
	text = data_add_number(btn_info);
	if (text) {
		view_create_text_popup(text);
	}

	if (text) {
		free(text);
	}
}

static void _extra_volup(button_info_s *btn_info)
{
	dlog_print(DLOG_INFO, "tag", "volup");
	SendMessage2("VolumeUp",*sock);

}
static void _extra_voldown(button_info_s *btn_info)
{
	dlog_print(DLOG_INFO, "tag","voldown");
	SendMessage2("VolumeDown",*sock);
}
static void _extra_mute(button_info_s *btn_info)
{
	dlog_print(DLOG_INFO, "tag", "mute");
	SendMessage2("VolumeMute",*sock);
}
static void _extra_power(button_info_s *btn_info)
{
	dlog_print(DLOG_INFO, "tag", "power");
	SendMessage2("PowerOn",*sock);
}
static void _extra_poweroff(button_info_s *btn_info)
{
	dlog_print(DLOG_INFO, "tag", "poweroff");
	SendMessage2("PowerOff",*sock);
}
static void _extra_move(button_info_s *btn_info)
{
	dlog_print(DLOG_INFO, "tag", "move");
	SendMessage2("Move",*sock);
}
static void _extra_channelup(button_info_s *btn_info)
{
	dlog_print(DLOG_INFO, "tag", "channelup");
	SendMessage2("ChannelUp",*sock);
}
static void _extra_channeldown(button_info_s *btn_info)
{
	dlog_print(DLOG_INFO, "tag", "channeldown");
	SendMessage2("ChannelDown",*sock);
}
static void _extra_reset(button_info_s *btn_info)//reset
{
	dlog_print(DLOG_INFO, LOG_TAG, "Reset button is clicked !!");

	/* Initialize each variables */
	data_set_value_on_reset();

	/* Display '|' when no formula is there */
	view_set_text_to_label("|");
}
static void _add_extra(button_info_s *btn_info)
{
	dlog_print(DLOG_INFO, LOG_TAG, "Extra button is clicked");
	switch (btn_info->button_val) {
	case KEY_VAL_RE:
		_extra_reset(btn_info);
		break;
	case KEY_VAL_VOLUP:
		_extra_volup(btn_info);
		break;
	case KEY_VAL_VOLDOWN:
		_extra_voldown(btn_info);
		break;
	case KEY_VAL_MUTE:
		_extra_mute(btn_info);
		break;
	case KEY_VAL_POWER:
		_extra_power(btn_info);
		break;
	case KEY_VAL_MOVE:
		_extra_move(btn_info);
		break;
	case KEY_VAL_CHANNELUP:
		_extra_channelup(btn_info);
		break;
	case KEY_VAL_CHANNELDOWN:
		_extra_channeldown(btn_info);
		break;
	case KEY_VAL_POWEROFF:
			_extra_poweroff(btn_info);
			break;
	default:
		break;
	}
	/* Just display '|', after reset button is clicked */
	if (btn_info->button_val == KEY_VAL_RE) {
		dlog_print(DLOG_INFO, "tag", "clear");
	} else {
		struct formula_info_s *formula_info = NULL;

		formula_info = data_get_formula_info();
		formula_info->formula_len = data_get_len_of_formula(formula_info->result_formula);

		view_display_formula(formula_info->displayed_formula, formula_info->formula_len);
	}
}

/**
 * @brief Function will be called when the button is clicked determining
 * what kind of button is clicked.
 * @param[in] data Information of the clicked button
 * @param[in] obj Clicked button
 * @param[in] event_info Information of the clicked event
 */
static void _button_clicked_cb(void *data, Evas_Object *obj, void *event_info)
{
	button_info_s *btn_info = (button_info_s *) data;
	dlog_print(DLOG_INFO, LOG_TAG, "button is clicked [ type: %d, %s ]", btn_info->button_type, btn_info->button_val_str);

	switch (btn_info->button_type) {
	case KEY_TYPE_EX:
		_add_extra(btn_info);
		break;
	case KEY_TYPE_NUM:
		_add_number(btn_info);
		break;
	default:
		break;
	}

	if (btn_info->button_type != KEY_TYPE_EX) {
		struct formula_info_s *formula_info = NULL;
		int formula_len = 0;

		formula_info = data_get_formula_info();
		formula_len = data_get_len_of_formula(formula_info->result_formula);

		view_display_formula(formula_info->displayed_formula, formula_len);
	}
}
pthread_t dd;
/**
 * @brief Hook to take necessary actions before main event loop starts.
 * @param[in] user_data The user data to be passed to the callback function
 * Initialize UI resources and application's data
 * If this function returns true, the main loop of application starts
 * If this function returns false, the application is terminated
 */
static bool app_create(void *user_data)
{
	int i;
	char file_path[PATH_MAX] = { 0, };

	sock = (int *) malloc(sizeof(int));

	InitSocket(sock);
	/* Get the path of EDJ file */
	data_get_resource_path(EDJ_FILE, file_path, sizeof(file_path));

	/* Initialize the new theme using EDJ file */
	view_init_calc_theme(file_path);

	/* Create window, conformant */
	view_create();

	/* Create specialized layout for the calculator using EDJ file */
	view_create_calc_layout(file_path, GRP_MAIN);

	/* Create label display the formula on the screen */
	view_create_calc_label();

	/* Create each button for the calculator */
	for (i = 0; i < CALC_BUTTON; i++) {
		view_create_calc_button(&BUTTON_PARAM[i], _button_clicked_cb);
	}

	//start_acceleration_sensor(user_data);



	pthread_create(&dd,NULL,start,(void*)user_data);

	return true;
}

/**
 * @brief This callback function is called when another application.
 * @param[in] app_control The handle to the app_control
 * @param[in] user_data The user data to be passed to the callback function
 * sends the launch request to the application
 */
static void app_control(app_control_h app_control, void *user_data)
{
	/* Handle the launch request. */
}

/**
 * @brief This callback function is called each time.
 * @param[in] user_data The user data to be passed to the callback function
 * the application is completely obscured by another application
 * and becomes invisible to the user
 */
static void app_pause(void *user_data)
{
	CloseSocket(sock);
	/* Take necessary actions when application becomes invisible. */
}

/**
 * @brief This callback function is called each time.
 * @param[in] user_data The user data to be passed to the callback function
 * the application becomes visible to the user
 */
static void app_resume(void *user_data)
{
	InitSocket(sock);
	/* Take necessary actions when application becomes visible. */
}

/**
 * @brief This callback function is called once after the main loop of the application exits.
 * @param[in] user_data The user data to be passed to the callback function
 */
static void app_terminate(void *user_data)
{
	CloseSocket(sock);
	/* Release all resources. */
	char file_path[PATH_MAX] = {0, };

	/* Get the EDJ file path */
	data_get_resource_path(EDJ_FILE, file_path, sizeof(file_path));

	/* Finalize the theme using EDJ file */
	view_fini_calc_theme(file_path);

	/* Destroy the window */
	view_destroy();
}

/**
 * @brief This function will be called when the language is changed.
 * @param[in] event_info The system event information
 * @param[in] user_data The user data to be passed to the callback function
 */
static void ui_app_lang_changed(app_event_info_h event_info, void *user_data)
{
	/*APP_EVENT_LANGUAGE_CHANGED*/
	char *locale = NULL;

	system_settings_get_value_string(SYSTEM_SETTINGS_KEY_LOCALE_LANGUAGE, &locale);

	if (locale != NULL) {
		elm_language_set(locale);
		free(locale);
	}
	return;
}

/**
 * @brief Main function of the application.
 * @param[in] argc The argument count
 * @param[in] argv The argument vector
 */
int main(int argc, char *argv[])
{
	int ret;

	ui_app_lifecycle_callback_s event_callback = {0, };
	app_event_handler_h handlers[5] = {NULL, };

	event_callback.create = app_create;
	event_callback.terminate = app_terminate;
	event_callback.pause = app_pause;
	event_callback.resume = app_resume;
	event_callback.app_control = app_control;

	/*
	 * If you want to handling more events,
	 * Please check the application lifecycle guide
	 */
	ui_app_add_event_handler(&handlers[APP_EVENT_LANGUAGE_CHANGED], APP_EVENT_LANGUAGE_CHANGED, ui_app_lang_changed, NULL);

	ret = ui_app_main(argc, argv, &event_callback, NULL);
	if (ret != APP_ERROR_NONE)
		dlog_print(DLOG_ERROR, LOG_TAG, "ui_app_main() is failed. err = %d", ret);

	return ret;
}
