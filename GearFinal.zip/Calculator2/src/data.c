/*
 * Copyright (c) 2016 Samsung Electronics Co., Ltd
 *
 * Licensed under the Flora License, Version 1.1 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://floralicense.org/license/
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <dlog.h>
#include <efl_extension.h>
#include <app_common.h>
#include <media_content.h>
#include "calculator2.h"
#include "data.h"


typedef enum {
	POPUP_TYPE_BIG_NUM = 0,
	POPUP_TYPE_TOO_MANY,
	POPUP_TYPE_DIVIDE_ZERO,
	POPUP_TYPE_TOO_LONG,
} popup_type;

/**
 * Variables for the formula.
 */
static struct formula_info_s formula_info = {
	.displayed_formula = { 0, },
	.result_formula = { 0, },
	.formula_len = 0,
	.number_index = 0,
	.number_count = { 0, },
	.is_multi_line = false,
	.last_one = { 0, },
	.result_num = { 0, },
};

static void _arrange_formula(int idx, bool is_blank);
static char *_check_condition_of_new_number(button_info_s *btn_info);

/*
 * @brief Initialization function for data module.
 */
void data_initialize(void)
{
	/*
	 * If you need to initialize managing data,
	 * please use this function.
	 */
}

/*
 * @brief Finalization function for data module.
 */
void data_finalize(void)
{
	/*
	 * If you need to finalize managing data,
	 * please use this function.
	 */
}

/*
 * @brief Gets path of resource.
 * @param[in] file_in File path of target file
 * @param[out] file_path_out Full file path concatenated with resource path
 * @param[in] file_path_max Max length of full file path
 */
void data_get_resource_path(const char *file_in, char *file_path_out, int file_path_max)
{
	char *res_path = app_get_resource_path();
	if (res_path) {
		snprintf(file_path_out, file_path_max, "%s%s", res_path, file_in);
		free(res_path);
	}
}

/*
 * @brief Gets the information of the formula.
 */
struct formula_info_s *data_get_formula_info(void)
{
	return &formula_info;
}

/*
 * @brief Gets string of the displayed formula.
 */
char *data_get_displayed_formula(void)
{
	return formula_info.displayed_formula;
}

/**
 * @brief Count length.
 * @param[in] formula Formula it's length should be counted
 */
int data_get_len_of_formula(char *formula)
{
	int len = 0;

	while (*formula) {
		len++;
		formula++;
	}
	dlog_print(DLOG_INFO, LOG_TAG, "length of formula is %d", len);

	return len;
}

/*
 * @brief Creates new string with original string.
 * @param[out] to_string The pointer will be store new string
 * @param[in] from_string The original string
 * @param[in] extra_string The extra string will be needed in case
 */
void data_copy_string_to_string(char *to_string, char *from_string, const char *extra_string)
{
	if (extra_string != NULL) {
		snprintf(to_string, 1024, "%s%s", from_string, extra_string);
	} else {
		snprintf(to_string, 1024, "%s", from_string);
	}
}

/*
 * @brief Initializes some variables when the reset button is clicked.
 * @param[in] type Type of the popup
 */
char *data_create_popup_text(int type)
{
	char popup_text[1024];


	switch (type) {
	case POPUP_TYPE_BIG_NUM:
		snprintf(popup_text, sizeof(popup_text), "this number is too big");
		break;
	case POPUP_TYPE_TOO_MANY:
		snprintf(popup_text, sizeof(popup_text), "too many numbers are there");
		break;
	/*case POPUP_TYPE_DIVIDE_ZERO:
		snprintf(popup_text, sizeof(popup_text), "you can't divide with zero");
		break;
		*/
	case POPUP_TYPE_TOO_LONG:
		snprintf(popup_text, sizeof(popup_text), "this formula is too long");
		break;
	default:
		return NULL;
	}

	return strdup(popup_text);
}

/*
 * @brief Initializes some variables for reset.
 */
void data_set_value_on_reset(void)
{
	int i;

	formula_info.formula_len = 0;
	formula_info.operand_is_possible = false;
	formula_info.is_multi_line = false;
	formula_info.decimal_is_possible = false;
	formula_info.blank_order = 0;
	formula_info.decimal_num = 0;
	formula_info.number_index = 0;
	for (i = 0; i < 10; i++) {
		formula_info.number_count[i] = 0;
	}

	/* Initialize displayed formula array as NULL */
	snprintf(formula_info.displayed_formula, sizeof(formula_info.displayed_formula), "");
	if (!memset(formula_info.displayed_formula, 0, sizeof(formula_info.displayed_formula))) {
		dlog_print(DLOG_ERROR, LOG_TAG, "failed to initialize the displayed formula");
	}

	/* Initialize result formula array as NULL */
	snprintf(formula_info.result_formula, sizeof(formula_info.result_formula), "");
	if (!memset(formula_info.result_formula, 0, sizeof(formula_info.result_formula))) {
		dlog_print(DLOG_ERROR, LOG_TAG, "failed to initialize the result formula");
	}
}

/*
 * @brief Adds new operand to the string.
 * @param[in] btn_info Information of the button
 */
void data_add_operand(button_info_s *btn_info)
{
	if (btn_info == NULL) {
		dlog_print(DLOG_ERROR, LOG_TAG, "Button info is NULL");
		return;
	}

	/* Count the length of the formula */
	formula_info.formula_len = data_get_len_of_formula(formula_info.result_formula);
	dlog_print(DLOG_INFO, LOG_TAG, "length of formula : %d", formula_info.formula_len);

	/* The length of the formula will be limited under 24 */
	if ((formula_info.formula_len > 24) || (formula_info.operand_is_possible == false)) {
		return;
	/* If the length of the displayed formula reached to 12, label start to display formula as multi line */
	} else if ((formula_info.formula_len > 11) && (!formula_info.is_multi_line)) {
		strcat(formula_info.displayed_formula, "</br>");
		formula_info.is_multi_line = true;
		formula_info.operand_is_possible = false;
	/* Just add input formula */
	} else {
		formula_info.operand_is_possible = false;
	}
	formula_info.formula_len += 1;

	/* Add input formula for display */
	strcat(formula_info.displayed_formula, btn_info->button_val_str);
	dlog_print(DLOG_INFO, LOG_TAG, "New display formula: %s", formula_info.displayed_formula);

	/* Add input formula for result */
	strcat(formula_info.result_formula, btn_info->button_val_str);
	dlog_print(DLOG_INFO, LOG_TAG, "New result formula: %s", formula_info.result_formula);

	/* Set the last one of the displayed formula as operand for next input */
	formula_info.last_one[formula_info.formula_len] = btn_info->button_val;

	/* After setting the operand, decimal can be used from now */
	formula_info.decimal_is_possible = false;
	/* Set the decimal number as 0 to set the decimal in the next number */
	formula_info.decimal_num = 0;
	formula_info.number_index += 1;
}

/*
 * @brief Checks whether more number can be added or not.
 * @param[in] btn_info Information of the button
 */
static char *_check_condition_of_new_number(button_info_s *btn_info)
{
	char *popup_text = NULL;

	/* This number is too big */
	if (formula_info.number_index >= 10) {
		dlog_print(DLOG_INFO, LOG_TAG, "Numbers in formula are more than 10");

		/* Create popup text */
		popup_text = data_create_popup_text(POPUP_TYPE_TOO_MANY);

		return popup_text;
	}
	dlog_print(DLOG_INFO, LOG_TAG, "formula_info.number_count[%d]: %d", formula_info.number_index, formula_info.number_count[formula_info.number_index]);

	/* We only display up to 5 digit in one number */
	if (formula_info.number_count[formula_info.number_index] > 5) {
		dlog_print(DLOG_INFO, LOG_TAG, "This number has digits more than 5, formula_info.number_count[%d]: %d", formula_info.number_index, formula_info.number_count[formula_info.number_index]);

		/* Create popup text */
		popup_text = data_create_popup_text(POPUP_TYPE_BIG_NUM);

		return popup_text;
	}

	/* Do not divide with 0, Number can't be located right after result number */
	if (btn_info->button_val == 0) {
		dlog_print(DLOG_INFO, LOG_TAG, "Divide with 0 or after result");

		/* Create popup text */
		popup_text = data_create_popup_text(POPUP_TYPE_DIVIDE_ZERO);

		return popup_text;
	}

	/* The length of the formula will be limited under 29 */
	if (formula_info.formula_len > 24) {
		dlog_print(DLOG_INFO, LOG_TAG, "More than 24 word");

		/* Create popup text */
		popup_text = data_create_popup_text(POPUP_TYPE_TOO_LONG);

		return popup_text;
	}

	return NULL;
}

/*
 * @brief Adds new number to the string.
 * @param[in] btn_info Information of the button
 */
char *data_add_number(button_info_s *btn_info)
{
	char *popup_text = NULL;

	if (btn_info == NULL) {
		dlog_print(DLOG_ERROR, LOG_TAG, "Button info is NULL");
		return NULL;
	}

	/* Count the length of the displayed formula */
	formula_info.formula_len = data_get_len_of_formula(formula_info.result_formula);
	dlog_print(DLOG_INFO, LOG_TAG, "length of formula : %d", formula_info.formula_len);

	/* Can't be added to the result number directly */
	if (formula_info.last_one[formula_info.formula_len] == KEY_VAL_AFTER_RESULT) {
		return NULL;
	}

	/* Check whether this number can be added or not */
	popup_text = _check_condition_of_new_number(btn_info);
	if (popup_text != NULL) {
		return popup_text;
	}

	/* If length reached to 12, add one more line */
	if ((formula_info.formula_len > 11) && (!formula_info.is_multi_line)) {
		dlog_print(DLOG_INFO, LOG_TAG, "over 11 words");
		strcat(formula_info.displayed_formula, "</br>");
		formula_info.is_multi_line = true;
	/* Just add input formula */
	} else {
		dlog_print(DLOG_INFO, LOG_TAG, "under 11 words");
	}

	formula_info.formula_len += 1;

	/* Change the state of 'operand_is_possible' to true */
	if (!formula_info.operand_is_possible) {
		formula_info.operand_is_possible = true;
	}

	/* Add input formula for display */
	strcat(formula_info.displayed_formula, btn_info->button_val_str);
	dlog_print(DLOG_INFO, LOG_TAG, "New display formula: %s", formula_info.displayed_formula);

	/* Add input formula for result */
	strcat(formula_info.result_formula, btn_info->button_val_str);
	dlog_print(DLOG_INFO, LOG_TAG, "New result formula: %s", formula_info.result_formula);

	/* Set the last one of the displayed formula as number for next input */
	formula_info.last_one[formula_info.formula_len] = btn_info->button_val;

	/* If there's no decimal in this number, decimal can be used next time */
	if (formula_info.decimal_num == 0) formula_info.decimal_is_possible = true;

	formula_info.number_count[formula_info.number_index] += 1;

	return NULL;
}

/*
 * @brief Deletes one formula.
 * @param[in] btn_info Information of the button
 */
void data_control_del_button(button_info_s *btn_info)
{
	dlog_print(DLOG_INFO, LOG_TAG, "Del button is clicked length of formula: %d!!", formula_info.formula_len);

	char temp[1024];
	char result_temp[1024];
	int displayed_len = 0;

	if (btn_info == NULL) {
		dlog_print(DLOG_ERROR, LOG_TAG, "Button info is NULL");
		return;
	}

	if (formula_info.formula_len <= 0) {
		return;
	}

	displayed_len = data_get_len_of_formula(formula_info.displayed_formula);

	/* '</br>' is included when the label started to display the formula as multi line
	 * and length of the formula has become 18 on that point
	 * So remove 5 + 1 length from the displayed formula
	 */
	if (formula_info.formula_len == 13) {
		dlog_print(DLOG_INFO, LOG_TAG, "Del button formula: %d!! reached", formula_info.formula_len);
		snprintf(temp, formula_info.formula_len, "%s", formula_info.result_formula);

		data_copy_string_to_string(formula_info.displayed_formula, temp, NULL);

		data_copy_string_to_string(formula_info.result_formula, temp, NULL);
		dlog_print(DLOG_INFO, LOG_TAG, "changed displayed formula : %s !!", temp);

		/* Update the multi line state as false */
		formula_info.is_multi_line = false;

	/* If the length of the displayed formula is longer than 18, just reduce the length by 1 */
	} else {
		snprintf(temp, displayed_len, "%s", formula_info.displayed_formula);
		snprintf(result_temp, formula_info.formula_len, "%s", formula_info.result_formula);

		data_copy_string_to_string(formula_info.result_formula, result_temp, NULL);
		dlog_print(DLOG_INFO, LOG_TAG, "changed result formula : %s !!", result_temp);

		data_copy_string_to_string(formula_info.displayed_formula, temp, NULL);
		dlog_print(DLOG_INFO, LOG_TAG, "changed displayed formula : %s !!", formula_info.displayed_formula);
	}

	/* Reduce the length of the displayed formula */
	if (formula_info.formula_len > 0) {
		formula_info.formula_len -= 1;
	}
	/* Initialize the value of the origin array as 0 */
	formula_info.last_one[formula_info.formula_len + 1] = 0;
}

/**
 * @brief Adds the blank to the displayed formula.
 * @param[in] btn_info Information of the pressed button
 */

/**
 * @brief Adds a decimal point to the displayed formula.
 * @param[in] btn_info Information of the pressed button
 */
static void _arrange_formula(int idx, bool is_blank)
{
	int i = 0;

	dlog_print(DLOG_INFO, LOG_TAG, "Arrange formula idx: %d", idx);

	/* If this time is for blank, two operands(must be blank) will be removed from the list */
	if (is_blank) {
		for (i = idx; i < 20; i++) {
			formula_info.result_op[i] = formula_info.result_op[i + 2];
		}
	/* After calculation, a operand and a number will be removed */
	} else {
		for (i = idx; i < 20; i++) {
			formula_info.result_num[i] = formula_info.result_num[i+1];
			formula_info.result_op[i] = formula_info.result_op[i+1];
		}
	}
	/* Display remained number will be calculated */
	for (i = 0; i < 7; i++) {
		dlog_print(DLOG_INFO, LOG_TAG, "displayed number: %f", formula_info.result_num[i]);
	}
	/* Display remained operand will be calculated */
	for (i = 0; i < 7; i++) {
		dlog_print(DLOG_INFO, LOG_TAG, "displayed op: %c", formula_info.result_op[i]);
	}
}
